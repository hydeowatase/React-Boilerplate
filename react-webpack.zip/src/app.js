'use strict'

import React from 'react'

const App = React.createClass({
    render: function () {
        return <h1>React App =D!!!</h1>
    }
})

export default App
