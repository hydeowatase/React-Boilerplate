'use strict'

//    ______            ______            ______
//   /\_____\          /\_____\          /\_____\          ____
//  _\ \__/_/_         \ \__/_/_         \ \__/_/         /\___\
// /\_\ \_____\        /\ \_____\        /\ \___\        /\ \___\
// \ \ \/ / / /        \ \/ / / /        \ \/ / /        \ \/ / /
//  \ \/ /\/ /          \/_/\/ /          \/_/_/          \/_/_/
//   \/_/\/_/              \/_/

import React from 'react'

const App = React.createClass({
    render: function () {
        return <h1>React App ****</h1>
    }
})

export default App
